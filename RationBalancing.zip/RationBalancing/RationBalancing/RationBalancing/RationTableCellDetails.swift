//
//  TableViewCellDetails.swift
//  RationBalancing
//
//  Created by student on 6/22/19.
//  Copyright © 2019 NWMSU. All rights reserved.
//

import UIKit

class RationTableCellDetails: UITableViewCell {

    @IBOutlet weak var textTF: UILabel!
    @IBOutlet weak var costTF: UITextField!
    @IBOutlet weak var percentageTF: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
