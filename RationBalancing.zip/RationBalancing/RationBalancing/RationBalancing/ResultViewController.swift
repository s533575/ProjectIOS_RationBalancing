//
//  ResultViewController.swift
//  RationBalancing
//
//  Created by student on 7/3/19.
//  Copyright © 2019 NWMSU. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    //var ingredientsList : [String] = []
    @IBOutlet weak var result1TVC: UITableView!
    @IBOutlet weak var result2TVC: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.result1TVC.delegate = self
        self.result1TVC.dataSource = self
        self.result2TVC.delegate = self
        self.result2TVC.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int)-> String? {
        if tableView == self.result1TVC {
            return ["Ration Details of Ingredients"][section]
        }
        if tableView == self.result2TVC {
            return ["Nutrient Range Predictor"][section]
        }
        return [""][section]
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.result1TVC {
            return 5
        }
        if tableView == self.result2TVC {
            return 5
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.result1TVC {
           let cell = tableView.dequeueReusableCell(withIdentifier: "result1", for: indexPath) as! ResultTableViewCellDetails
            //cell.ingredients.text!
            //cell.ingredients!.text = DetailViewController.selectedIngredients[indexPath.row]
            return cell
        }
        
        if tableView == self.result2TVC {
            let cell = tableView.dequeueReusableCell(withIdentifier: "result2")
            return cell!
        }
        return UITableViewCell()
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
}
