# RationBalancing
What particular information should be provided in the Help screen?
Does the pounds in ration values should be given by the user or default values?

